# Информация о фале конфигурации системы
# Можно было бы класс со статическими переменными сделать, но лень ...
# Пока таких переменных не слишком много - пусть так остается
config: any
tags: any
log_file: str
setting_up_field_lists: dict
field_type_list: dict
excel_data_definition: dict
